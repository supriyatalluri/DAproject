from keras.preprocessing import image
from keras.applications.resnet50 import preprocess_input
import numpy as np
from keras.models import load_model

model=load_model('C:/Users/Supriya/Desktop/DA Project/resnet50.h5')
img_path = 'C:/Users/Supriya/Desktop/DA Project/clahe/163_left.jpeg'
img = image.load_img(img_path, target_size=(224, 224))
x = image.img_to_array(img)
x = np.expand_dims(x, axis=0)
x = preprocess_input(x)
names = ['NoDR','EarlyDR','ModerateDR','SevereDR','NPDR']
features = model.predict(x)

print(features)
print(names[np.argmax(features)])