from keras.preprocessing import image
from keras.applications.resnet50 import preprocess_input
import numpy as np
from keras.layers import Input
from keras.models import Model
from keras.utils import np_utils
from keras.optimizers import SGD
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
import pandas as pd
import pickle
import os
import random
from keras.models import load_model
from keras.applications.inception_v3 import preprocess_input
from keras.applications.vgg16 import preprocess_input
from keras.models import Sequential
from keras.layers import Dense
from keras.wrappers.scikit_learn import KerasClassifier
from sklearn.model_selection import cross_val_score
from sklearn.model_selection import KFold
from sklearn.preprocessing import LabelEncoder
from sklearn.pipeline import Pipeline

model1=load_model('C:/Users/Supriya/Desktop/DA Project/resnet50.h5')
model2=load_model('C:/Users/Supriya/Desktop/DA Project/vgg16.h5')
model3=load_model('C:/Users/Supriya/Desktop/DA Project/inception.h5')

data_path = 'C:/Users/Supriya/Desktop/DA Project/clahe/'

img_data_list=[]
img_list=os.listdir(data_path)
print ("Loaded the images of dataset")
for img in img_list:
    img_path = data_path + img
    img = image.load_img(img_path, target_size=(224, 224))
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    img_data_list.append(x)
img_data = np.array(img_data_list)
# Define the number of classes
num_classes = 5
num_of_samples = img_data.shape[0]
labels = np.ones((num_of_samples,),dtype='int64')
data=pd.read_csv('C:/Users/Supriya/Desktop/DA Project/newlabels.csv')
data= np.array(data)
r,c =data.shape
mp={}
for i in range(0,r):
	mp[str(str(data[i][2])+'.jpeg')] = data[i][1]
print(mp)
train_input = []
train_output = []
train_output_num = []
names = ['NoDR','EarlyDR','ModerateDR','SevereDR','NPDR']
src_path='C:/Users/Supriya/Desktop/DA Project/clahe/'
random.shuffle(img_list)
img_list = img_list[:100]
for img in img_list:
    if not((os.path.isfile(src_path+img)) or (img.endswith('.jpeg')) ):
        continue
    t = img
    img_path = data_path + img
    img = image.load_img(img_path, target_size=(224, 224))
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    features1 = model1.predict(x).tolist()
    features2 = model2.predict(x).tolist()
    features3 = model3.predict(x).tolist()
    temp = features1 + features2 + features3
    k = []
    for f in temp:
        for g in f:
            k.append(g)
    temp = k
    train_input.append(temp)
    solution = mp.get(t)
    if(solution == 0):
        temp = [1,0,0,0,0]
    if(solution == 1):
        temp = [0,1,0,0,0]
    if(solution == 2):
        temp = [0,0,1,0,0]
    if(solution == 3):
        temp = [0,0,0,1,0]
    if(solution == 4):
        temp = [0,0,0,0,1]
    train_output.append(temp)
    train_output_num.append(solution)
    
#Averaging
temp_result = []
for i in train_input:
    temp = []
    for j in range(5):
        t = i[j] + i[2*j] +i[3*j]
        t = t/3
        temp.append(t)
    temp_result.append(temp)
print("Averaging accuracy")
total = 0
correct = 0
for i in temp_result:
    if(i.index(max(i)) == train_output_num[total]):
        correct = correct + 1
    total = total + 1
print("accuracy - " , correct/total)

    
#Max
temp_result = []
for i in train_input:
    max1 = i.index(max(i[0:5]))
    max2 = i.index(max(i[5:10])) - 5
    max3 = i.index(max(i[10:15])) - 10
    t = []
    t.append(max1)
    t.append(max2)
    t.append(max3)
    if(t.count(max1)>1):
        temp_result.append(max1)
    elif(t.count(max2)>1):
        temp_result.append(max2)
    else:
        temp_result.append(max1)
print("Voting accuracy")
total = 0
correct = 0
for i in temp_result:
    if(i == train_output_num[total]):
        correct = correct + 1
    total = total + 1
print("accuracy - " , correct/total)

#Weighted
temp_result = []
for i in train_input:
    temp = []
    for j in range(5):
        a1 = 48 #resnet
        a2 = 69 #vgg
        a3 = 59 #inception
        t = a1*i[j] + a2*i[2*j] + a3*i[3*j]
        t = t/(a1 + a2 + a3)
        temp.append(t)
    temp_result.append(temp)
print("Averaging accuracy")
total = 0
correct = 0
for i in temp_result:
    if(i.index(max(i)) == train_output_num[total]):
        correct = correct + 1
    total = total + 1
print("accuracy - " , correct/total)


    
    
    