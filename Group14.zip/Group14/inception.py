import numpy as np
import os
import time
import matplotlib.pyplot as plt
from keras.applications.inception_v3 import InceptionV3
from keras.preprocessing import image
from keras.layers import GlobalAveragePooling2D, Dense, Dropout,Activation,Flatten
from keras.applications.inception_v3 import preprocess_input,decode_predictions
from keras.models import load_model
from keras.layers import Input
from keras.models import Model
from keras.utils import np_utils
from keras.optimizers import SGD
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
import pandas as pd
import random
import pickle

data_path = 'C:/Users/Supriya/Desktop/DA Project/clahe/'

img_data_list=[]
img_list=os.listdir(data_path)
random.shuffle(img_list)
print ("Loaded the images of dataset")
for img in img_list:
    img_path = data_path + img
    img = image.load_img(img_path, target_size=(224, 224))
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    img_data_list.append(x)

img_data = np.array(img_data_list)
print (img_data.shape)
img_data=np.rollaxis(img_data,1,0)
img_data=img_data[0]

# Define the number of classes
num_classes = 5
num_of_samples = img_data.shape[0]
labels = np.ones((num_of_samples,),dtype='int64')

data=pd.read_csv('C:/Users/Supriya/Desktop/DA Project/newlabels.csv')
data= np.array(data)
r,c =data.shape
mp={}
for i in range(0,r):
	mp[str(str(data[i][2])+'.jpeg')] = data[i][1]
i=0
src_path='C:/Users/Supriya/Desktop/DA Project/clahe/'
dirs=os.listdir(src_path)
for img in img_list:
	if not((os.path.isfile(src_path+img)) or (img.endswith('.jpeg')) ):
		continue
	print(img)
	labels[i]=(mp.get(img))
	i=i+1

# convert class labels to on-hot encoding
Y = np_utils.to_categorical(labels, num_classes)

#Shuffle the dataset
x,y = shuffle(img_data,Y, random_state=2)
# Split the dataset
X_train, X_test, y_train, y_test = train_test_split(x, y, test_size=0.2)

#using pre trained weights and fine tuning
image_input = Input(shape=(224, 224, 3))
model = InceptionV3(input_tensor=image_input, include_top=True,weights='imagenet')
last_layer = model.output

x = Dense(512, activation='relu',name='fc-1')(last_layer)
x = Dropout(0.5)(x)
x = Dense(256, activation='relu',name='fc-2')(x)
x = Dropout(0.5)(x)
# a softmax layer for 5 classes
out = Dense(num_classes, activation='softmax',name='output_layer')(x)

inception_model = Model(inputs=image_input,outputs= out)
for layer in inception_model.layers[:-6]:
	layer.trainable = False
inception_model.layers[-1].trainable = True

inception_model.compile(loss='categorical_crossentropy',optimizer='adam',metrics=['accuracy'])


hist = inception_model.fit(X_train, y_train, batch_size=10, epochs=10, verbose=1, validation_data=(X_test, y_test))
inception_model.save('inception.h5')

(loss, accuracy) = inception_model.evaluate(X_test, y_test, batch_size=10, verbose=1)

print("[INFO] loss={:.4f}, accuracy: {:.4f}%".format(loss,accuracy * 100))






