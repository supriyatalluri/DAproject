from keras.preprocessing import image
from keras.applications.inception_v3 import preprocess_input
import numpy as np
from keras.models import load_model
from keras import backend as K
from PIL import Image
import cv2


def rotated(array_2d):
    list_of_tuples = zip(*array_2d[::-1])
    return [list(elem) for elem in list_of_tuples]
 
def final_zoomout(layer , size , old ):
    diff = size - old
    gap = int(old/diff)
    position = gap
    count = 0 
    while(count<diff):
        layer.insert(position , layer[position-1])
        position = position + gap
        count = count + 1
    layer = rotated(layer)
    position = gap
    count = 0 
    while(count<diff):
        layer.insert(position , layer[position-1])
        position = position + gap
        count = count + 1
    layer = rotated(layer)
    return layer

def rec_zoomout(layer , size , old):
    temp = [[0.0 for i in range(old)] for j in range(size)]
    for i in range(len(layer)):
        for j in range(len(layer[0])):
            temp[2*i][j] = layer[i][j]
    for i in range(len(temp)):
        for j in range(len(temp[0])):
            if(i%2==1 and i>=1 and i<=size-1):
                temp[i][j] = (temp[i-1][j] + temp[i+1][j]) /2

    temp1 = [[0.0 for i in range(size)] for j in range(size)]
    for i in range(len(temp)):
        for j in range(len(temp[0])):
            temp1[i][2*j] = temp[i][j]
    for i in range(len(temp1)):
        for j in range(len(temp1[0])):
            if(j%2==1 and j>=1 and j<=size-1):
                temp1[i][j] = (temp1[i][j-1] + temp1[i][j+1]) /2
    return temp1

def zoomout(layer , finalsize):
    size = len(layer)
    newsize = 2*size-1 
    if(newsize < finalsize):
        layer = rec_zoomout(layer,newsize , size)
        size = len(layer)
    if(newsize!=finalsize):
        layer = final_zoomout(layer , finalsize , newsize)
    return layer

model=load_model('C:/Users/Supriya/Desktop/DA Project/inception.h5')
img_path = 'C:/Users/Supriya/Desktop/DA Project/clahe/163_left.jpeg'
img = image.load_img(img_path, target_size=(224, 224))
x = image.img_to_array(img)
print(x)
x = np.expand_dims(x, axis=0)
x = preprocess_input(x)
names = ['NoDR','EarlyDR','ModerateDR','SevereDR','NPDR']
features = model.predict(x)
print(features)
print(names[np.argmax(features)])

layer = [model.layers[-3].output]
functor = K.function([model.input , K.learning_phase()] , layer)
layer_out = functor([x , 1.])
layer_out = layer_out[0][0]

layer_out = layer_out.tolist()
temp = [ [0.0 for i in range(16)] for j in range(16)]

count = 0
for i in range(16):
    for j in range(16):
        temp[i][j] = layer_out[count]
        count = count + 1
layer_out = zoomout(temp, 299)

maxval = max(max(x) for x in layer_out) 
minval = min(max(x) for x in layer_out) 
avgval = (maxval + minval)/2

img=Image.open(img_path)
size = 299,299
img=img.resize(size, Image.ANTIALIAS);
pix=img.load()
wd,ht=img.size

for i in range(0,wd):
    for j in range(0,ht):
        if(layer_out[j][i]>avgval):
            print("hello")
            pix[i,j] = (0,0,255)

img.save("C:/Users/Supriya/Desktop/DA Project/a.jpeg" , "JPEG")



