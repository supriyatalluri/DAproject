from PIL import Image
import os, sys
size_1=700,700;
size_2=512,512;

src = 'C:/Users/Supriya/Desktop/DA Project/dataset/'

dirs = os.listdir(src);

for img2 in dirs: 
    if not((os.path.isfile(src+img2)) or (img2.endswith('.jpeg')) ):
        continue;
    img=Image.open(src+img2);
    img=img.resize(size_1, Image.ANTIALIAS);
    wd,ht=img.size;
    pix=img.load();
    for i in range(0,ht):
        for j in range(0,wd):
            if pix[j,i]>(25,25,25):
    #            print(pix[j,i])
                break;
        if pix[j,i]>(25,25,25):
            break;
    ht1=i;  #black height from top

    i=ht-1;
    while i>0:
        for j in range(0,wd):
            if pix[j,i]>(25,25,25):
                break;
        if pix[j,i]>(25,25,25):
            break;
        i=i-1;
    ht2=i;
    for i in range(0,wd):
        for j in range(0,ht):
            if pix[i,j]>(25,25,25):
                break;
        if pix[i,j]>(25,25,25):
            break;
    wd1=i;
    i=wd-1;
    while i>0:
        for j in range(0,ht):
            if pix[i,j]>(25,25,25):
                break;
        if pix[i,j]>(25,25,25):
            break;
        i=i-1;
    wd2=i;
    img3=img.crop((wd1,ht1,wd2,ht2));
    path='./';
    img3=img3.resize(size_2, Image.ANTIALIAS);
    img3.save('C:/Users/Supriya/Desktop/DA Project/black/'+img2);
