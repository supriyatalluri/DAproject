from keras.preprocessing import image
from keras.applications.vgg16 import preprocess_input
import numpy as np
from keras.models import load_model
import tensorflow as tf
import utils

img_path = 'C:/Users/Supriya/Desktop/DA Project/clahe/163_left.jpeg'
img1 = image.load_img(img_path, target_size=(224, 224))
x = image.img_to_array(img1)
x = np.expand_dims(x, axis=0)
x = preprocess_input(x)

print(features)
print(names[np.argmax(features)])
