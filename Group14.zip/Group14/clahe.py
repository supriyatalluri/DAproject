import cv2
import os,sys

dirs = os.listdir('C:/Users/Supriya/Desktop/DA Project/black/')
for img in dirs : 
	if img.endswith('.jpeg') :
		img2 = cv2.imread('C:/Users/Supriya/Desktop/DA Project/black/' + img)
		clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
		b,g,r=cv2.split(img2)
		cl_b = clahe.apply(b)
		cl_g = clahe.apply(g)
		cl_r = clahe.apply(r)
		cl_rgb = cv2.merge([cl_b,cl_g,cl_r]);
		cv2.imwrite('C:/Users/Supriya/Desktop/DA Project/clahe/'+img,cl_rgb)
print("DONE -- CLAHE")