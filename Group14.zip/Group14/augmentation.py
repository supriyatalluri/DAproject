import pandas as pd
import numpy as np
from skimage import io
from skimage.transform import rotate
import cv2
import os


def rotate_images(file_path, degrees_of_rotation, lst_imgs):
    for l in lst_imgs:
        if(os.path.isfile(file_path + str(l) + '.jpeg')):
            img = io.imread(file_path + str(l) + '.jpeg')
            img = rotate(img, degrees_of_rotation)
            io.imsave(file_path + str(l) + '_' + str(degrees_of_rotation) + '.jpeg', img)


def mirror_images(file_path, mirror_direction, lst_imgs):
    for l in lst_imgs:
        if(os.path.isfile(file_path + str(l) + '.jpeg')):
            img = cv2.imread(file_path + str(l) + '.jpeg')
            img = cv2.flip(img, 1)
            cv2.imwrite(file_path + str(l) + '_mir' + '.jpeg', img)

            
def get_lst_images(file_path):
    return [i for i in os.listdir(file_path) if i != '.DS_Store']


if __name__ == '__main__':
    trainLabels = pd.read_csv("C:/Users/Supriya/Desktop/DA Project/labels.csv")
    trainLabels['image'] = trainLabels['image'].str.rstrip('.jpeg')
    trainLabels_no_DR = trainLabels[trainLabels['level'] == 0]
    trainLabels_DR = trainLabels[trainLabels['level'] >= 1]

    lst_imgs_no_DR = [i for i in trainLabels_no_DR['image']]
    lst_imgs_DR = [i for i in trainLabels_DR['image']]

    # Mirror Images with no DR one time
    print("Mirroring Non-DR Images")
    mirror_images('C:/Users/Supriya/Desktop/DA Project/clahe/', 1, lst_imgs_no_DR)


    # Rotate all images that have any level of DR
    print("Rotating 90 Degrees")
    rotate_images('C:/Users/Supriya/Desktop/DA Project/clahe/', 90, lst_imgs_DR)

    print("Rotating 120 Degrees")
    rotate_images('C:/Users/Supriya/Desktop/DA Project/clahe/', 120, lst_imgs_DR)

    print("Rotating 180 Degrees")
    rotate_images('C:/Users/Supriya/Desktop/DA Project/clahe/', 180, lst_imgs_DR)

    print("Rotating 270 Degrees")
    rotate_images('C:/Users/Supriya/Desktop/DA Project/clahe/', 270, lst_imgs_DR)

    print("Mirroring DR Images")
    mirror_images('C:/Users/Supriya/Desktop/DA Project/clahe/', 0, lst_imgs_DR)

    print("Completed")
    
    print("Generating CSV file")
    
    lst_imgs = get_lst_images('C:/Users/Supriya/Desktop/DA Project/clahe/')

    new_trainLabels = pd.DataFrame({'image': lst_imgs})
    new_trainLabels['image2'] = new_trainLabels.image

    # Remove the suffix from the image names.
    new_trainLabels['image2'] = new_trainLabels.loc[:, 'image2'].apply(lambda x: '_'.join(x.split('_')[0:2]))
    new_trainLabels['image2'] = new_trainLabels.loc[:, 'image2'].apply(
        lambda x: '_'.join(x.split('_')[0:2]).strip('.jpeg') )

    # trainLabels = trainLabels[0:10]
    new_trainLabels['image'] = new_trainLabels.loc[:, 'image'].apply(
        lambda x: x.strip('.jpeg') )
    new_trainLabels.columns = ['train_image_name', 'image']

    trainLabels = pd.merge(trainLabels, new_trainLabels, how='right', on='image')

    print(trainLabels.shape)

    print("Writing CSV")
    trainLabels.to_csv('C:/Users/Supriya/Desktop/DA Project/newlabels.csv', index=False, header=True)

    
    
